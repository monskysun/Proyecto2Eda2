package proyecto2;

import java.util.LinkedList;
import java.util.Queue;

// 1-dic-2021
//BY MONSE
// Es un max-Heap
public class HeapTree {
	 Nodo root;
	 //Para inicializar la raiz en null
	   public HeapTree (){
	        root=null;
	    }
	   // Para inicializar la raíz con un nodo existente
	   public void HeapTree(Nodo root){
	        this.root=root;
	    }
	  //Para saber si el nuevo hijo es mayor que el padre
	   public int comparacion(Nodo hijo) {
		   Nodo aux = new Nodo();
		   if( hijo.padre != null) {
			   Nodo padre =  hijo.padre;
			   if(hijo.valor > padre.valor) {
				   aux.valor = padre.valor;
				   padre.valor= hijo.valor;
				   hijo.valor = aux.valor;
				   comparacion(hijo.padre);
			   }
			   return 1;
		   }
		   else 
			   return 0;
			   
	   }
	   //Para insertar A la izquierda
	   public void insertarIzq(Nodo padre, Nodo hijo) {
		   padre.setIzq(hijo);
		   hijo.setPadre(padre);
		   comparacion(hijo);
		   
		   
	   }
	   //Para insertar a la derecha
	   public void insertarDer(Nodo padre, Nodo hijo) {
		   padre.setDer(hijo);
		   //padre.der = hijo;
		   hijo.setPadre(padre);
		   comparacion(hijo);
		   
	   }
	 //Para insertar a la izquierda y a la derecha
	   public int insertarHijos(Nodo root, Nodo NodoHijo) {
			if(root.izq == null) {
		   		insertarIzq(root, NodoHijo);
		   		return 1;
		   
		   	}
		   	else if(root.der == null) {
		   		insertarDer(root, NodoHijo);
		   		return 1;
		   		}
			return 0;
		   
	   }
	   //Mucho ojo, la funcion anterior se puede utilizar para add
	   
	   //Para agregar un nodo
	   
	   public int add(Nodo root, Nodo NodoHijo){
		   	int insertado = 0;
		   	if(root.izq == null) {
		   		insertarIzq(root, NodoHijo);
		   		return 1;
		   	}
		   	else if(root.der == null) {
		   		insertarDer(root, NodoHijo);
		   		return 1;
		   	// Hasta aquí ya se insertaron los primeros 3 nodos
		   	}
		   	else if(root.izq != null && root.der != null) {
		   		//Aquí puede empezar la recursividad
		   		//o un ciclo while
		   		Nodo padreIzq = root.izq; // avanza a la izq
		   		Nodo padreDer= root.der;  // avanza a la der 
		   		
		   		insertado = insertarHijos(padreIzq,NodoHijo);//nos vamos por sub izq
		   		
		   		if(insertado==1) {
		   			return insertado;
		   		// Hasta aquí ya se insertaron los hijos del segundo nodo
		   		}
		   		else
		   		{
		   			insertado = insertarHijos(padreDer,NodoHijo); //nos vamos por sub der
		   			if(insertado==1) {
			   			return insertado;
			   		// Hasta aquí ya se insertaron los hijos del tercer nodo
			   		}
		   			else {
		   				//OJITO
			   			 padreIzq =  padreIzq .izq; // nos vamos por el sub izq del sub izq
			   			//OJITO\n
			   			 insertado = insertarHijos(padreIzq,NodoHijo); // nos vamos por el sub izq del sub izq
			   			 if(insertado==1) {
				   			return insertado;
				   		 // Hasta aquí ya se insertaron los hijos del cuarto nodo
			   			 }
			   			 else {
			   				 //0J0
			   				 padreIzq = padreIzq.padre; //Se regresa al sub izq
			   				 //0J0\n
			   				 //OK
			   				 padreIzq = padreIzq.der;  // nos vamos por el sub der del sub izq
			   				 //OK\n
			   				 insertado = insertarHijos(padreIzq,NodoHijo);
			   				 if(insertado==1) {
						   			return insertado;
						   		 // Hasta aquí ya se insertaron los hijos del quinto nodo
					   			 }
			   				 else {
			   					//0J0
			   					padreIzq = padreIzq.padre; //Se regresa al sub izq
			   					//0J0\n
			   					//OJITO
			   					padreDer = padreDer.izq; // nos vamos por el sub izq del sub der
			   					//OJITO\n
			   					insertado = insertarHijos(padreDer,NodoHijo);
			   					if(insertado==1) {
						   			return insertado;
						   		 // Hasta aquí ya se insertaron los hijos del sexto nodo
					   			}
			   					else {
			   						//0J0
			   						padreDer = padreDer.padre; // Se regresa al sub der
			   						//0J0\n
			   						//OK
			   						padreDer = padreDer.der;  // nos vamos por el sub der del sub der
			   						//OK\n
			   						insertado = insertarHijos(padreDer,NodoHijo);
			   						if(insertado==1) {
							   			return insertado;
							   		 // Hasta aquí ya se insertaron los hijos del septimo nodo
						   			}
			   						else {
			   						//0J0
			   							padreDer = padreDer.padre; // Se regresa al sub der
				   					//0J0\n
			   						}
			   					}
			   				 }
			   			 }
			   				 
		   			}
		   			
		   		}
		   	}
			return insertado;
	    }
	    
	  // ------------BreadthFirts---------------
	   protected void visit(Nodo n){
	        System.out.println(n.valor+" ");
	    }	
	    
	    public void breadthFrist(){
		        Nodo r = root;
			Queue<Nodo> queue = new LinkedList();
			if(r!=null){
		        queue.add(r);
		        while(!queue.isEmpty()){
			        r = (Nodo)queue.poll();
					visit(r);
					if(r.izq!=null)
			            queue.add(r.izq);
					if(r.der!=null)
						queue.add(r.der);
		        }
			}
	    }
	 // ------------BreadthFirts---------------\n
	  

	    
}
