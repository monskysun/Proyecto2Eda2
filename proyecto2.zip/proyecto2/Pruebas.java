package proyecto2;

import java.util.Scanner;


public class Pruebas {
	 public static void main(String args[]){
		 
	    	Scanner guarda = new Scanner(System.in);
	    	HeapTree ArbolHeap = new HeapTree();
	    	//introduce el valor de la raíz
	    	Nodo root = new Nodo(10);
	    	ArbolHeap.HeapTree(root);
	    	root.printHijos();//prueba
	    	
	    	Nodo izq = new Nodo(7);
	    	Nodo der = new Nodo(15);
	    	ArbolHeap.add(root,izq);
	    	root.printHijos();//prueba
	    	ArbolHeap.add(root,der);
	    	//ArbolHeap.breadthFrist();
	    	
	    	root.printHijos();
	    	
	    	Nodo nuevo = new Nodo(16);
	    	ArbolHeap.add(root,nuevo);
	    	
	    	Nodo nuevo2 = new Nodo (9);
	    	ArbolHeap.add(root,nuevo2);
	    	
	    	Nodo nuevo3 = new Nodo (12);
	    	ArbolHeap.add(root,nuevo3);
	    	
	    	Nodo nuevo4 = new Nodo (21);
	    	ArbolHeap.add(root,nuevo4);
	    	
	    	root.printHijos();
	    	izq.printHijos();
	    	
	    	der.printHijos();
	       
	 }
}
